document.addEventListener('DOMContentLoaded', function() {
  const threadsList = document.getElementById('threads-list');
  const threadDetails = document.getElementById('thread-details');
  const toggleThemeButton = document.getElementById('toggle-theme');

  // Toggle between light and dark mode
  toggleThemeButton.addEventListener('click', function() {
      document.body.classList.toggle('dark-mode');
      document.body.classList.toggle('light-mode');
  });

  // Fetch list of threads
  fetch('/onebox/list')
      .then(response => response.json())
      .then(data => {
          threadsList.innerHTML = data.map(thread => `<div data-id="${thread.id}" class="thread">${thread.title}</div>`).join('');
      });

  // Handle thread click
  threadsList.addEventListener('click', function(event) {
      if (event.target.classList.contains('thread')) {
          const threadId = event.target.getAttribute('data-id');
          fetch(`/onebox/${threadId}`)
              .then(response => response.json())
              .then(data => {
                  threadDetails.innerHTML = `<h2>${data.title}</h2><p>${data.body}</p>`;
              });
      }
  });

  // Implement keyboard shortcuts
  document.addEventListener('keydown', function(event) {
      const threadId = document.querySelector('.thread.active')?.getAttribute('data-id');
      if (!threadId) return;

      if (event.key === 'D') {
          fetch(`/onebox/${threadId}`, { method: 'DELETE' })
              .then(() => {
                  // Remove thread from UI
                  document.querySelector(`.thread[data-id="${threadId}"]`).remove();
                  threadDetails.innerHTML = '';
              });
      }

      if (event.key === 'R') {
          // Open reply box (implement this)
          openReplyBox(threadId);
      }
  });
});

function openReplyBox(threadId) {
  // Implement reply box UI and functionality
  const replyBoxHtml = `
      <div class="reply-box">
          <input type="text" id="reply-subject" placeholder="Subject">
          <textarea id="reply-body" placeholder="Reply..."></textarea>
          <button id="send-reply">Send</button>
      </div>
  `;
  document.getElementById('thread-details').innerHTML += replyBoxHtml;

  document.getElementById('send-reply').addEventListener('click', function() {
      const replySubject = document.getElementById('reply-subject').value;
      const replyBody = document.getElementById('reply-body').value;

      fetch(`/reply/${threadId}`, {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify({
              from: 'your-email@example.com',
              to: 'recipient@example.com',
              subject: replySubject,
              body: replyBody
          })
      });
  });
}
